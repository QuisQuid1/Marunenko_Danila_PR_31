﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace Marunenko_Danila_PR_31_zd_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("input.txt");
            StreamWriter sw = new StreamWriter("output.txt");
            int N = int.Parse(sr.ReadLine());
            string[] input = sr.ReadLine().Split();
            int v = int.Parse(input[0]);
            int t = int.Parse(input[1]);
            int dist = v * t;
            int k = dist % N;
            sw.WriteLine(k);
            sr.Close();
            sw.Close();
            Console.ReadKey();
        }
    }
}
